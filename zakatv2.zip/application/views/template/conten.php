<?php 
$this->load->view('template/header');
$this->load->view('template/navbar');
$this->load->view($conten);
$this->load->view('template/footer');
